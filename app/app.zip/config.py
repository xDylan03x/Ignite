import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(__file__))

SECRET_KEY = os.environ.get('SECRET_KEY') or '1EbYz0MUk6YCs6Doj313kzUxpI7TJ293'
SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///' + os.path.join(basedir, 'ignite.db')
SQLALCHEMY_TRACK_MODIFICATIONS = False
SENDGRID_KEY = "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"  # https://app.sendgrid.com/settings/api_keys create a new key with full access
REMEMBER_COOKIE_DURATION = timedelta(days=10)
PERMANENT_SESSION_LIFETIME = timedelta(days=10)
# REMEMBER_COOKIE_DOMAIN = ".127.0.0.1"  # ".SITEDOMAIN.com"
